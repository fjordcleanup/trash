export var TrashType = /*#__PURE__*/ function(TrashType) {
    TrashType["Escooter"] = "escooter";
    TrashType["Bulk"] = "bulk";
    TrashType["Litter"] = "litter";
    TrashType["Other"] = "other";
    return TrashType;
}({});
