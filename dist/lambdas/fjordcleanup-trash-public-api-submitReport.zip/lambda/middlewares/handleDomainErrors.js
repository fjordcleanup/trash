import { aProblem } from '@hello.nrfcloud.com/lambda-helpers/aProblem';
import { ValidationFailedError } from '@hello.nrfcloud.com/lambda-helpers/validateInput';
import { formatTypeBoxErrors } from '@hello.nrfcloud.com/proto';
import { HttpStatusCode } from '@hello.nrfcloud.com/proto/hello';
export const handleDomainErrors = ()=>({
        onError: async (req)=>{
            if (req.response !== undefined) return;
            if (req.error instanceof ValidationFailedError) {
                req.response = aProblem({
                    status: HttpStatusCode.BAD_REQUEST,
                    title: 'Invalid input',
                    detail: formatTypeBoxErrors(req.error.errors)
                });
                return;
            }
            console.error('[handleDomainErrors]', JSON.stringify(req.error));
            req.response = aProblem({
                status: HttpStatusCode.INTERNAL_SERVER_ERROR,
                title: req.error instanceof Error ? req.error.message : 'Internal Server Error',
                detail: req.error instanceof Error ? req.error.name : undefined
            });
            req.error = null;
        }
    });
